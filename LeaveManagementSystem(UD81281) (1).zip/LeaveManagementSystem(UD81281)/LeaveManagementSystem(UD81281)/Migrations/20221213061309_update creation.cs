﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace LeaveManagementSystem_UD81281_.Migrations
{
    public partial class updatecreation : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<int>(
                name: "EmployeeId",
                table: "Leaves",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.AddColumn<string>(
                name: "ManagerName",
                table: "Employees",
                nullable: true);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "EmployeeId",
                table: "Leaves");

            migrationBuilder.DropColumn(
                name: "ManagerName",
                table: "Employees");
        }
    }
}
