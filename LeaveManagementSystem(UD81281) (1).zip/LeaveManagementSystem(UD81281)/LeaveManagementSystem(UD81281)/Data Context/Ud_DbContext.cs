﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using LeaveManagementSystem_UD81281_.Models;

namespace LeaveManagementSystem_UD81281_.Models
{
    public class Ud_DbContext : DbContext
    {
        public Ud_DbContext(DbContextOptions options) : base(options)
        {

        }
        public DbSet<Employee> Employees { get; set; }
        public DbSet<Leave> Leaves { get; set; }
        public DbSet<Manager> Managers { get; set; }
        public DbSet<Login> Logins { get; set; }
        public DbSet<LoginManager> LoginManagers { get; set; }



    }
}