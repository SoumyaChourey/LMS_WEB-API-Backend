﻿using AutoMapper;
using LeaveManagementSystem_UD81281_.Models;
using LeaveManagementSystem_UD81281_.Repository;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
namespace Leave_Management_System_UD81281_.Repository
{
    public class LeaveRepo : ILeave
    {
        private readonly Ud_DbContext ud_DbContext;

        public LeaveRepo(Ud_DbContext ud_DbContext)
        {
            this.ud_DbContext = ud_DbContext;
        }
        public async Task<int> AddLeaves(Leave leaves)
        {
            var le = new Leave()
            {
                LeaveId = leaves.LeaveId,
                NoOfDays = leaves.NoOfDays,
                StartDate = leaves.StartDate,
                EndDate = leaves.EndDate,
                LeaveType = leaves.LeaveType,
                Status = leaves.Status,
                Reason = leaves.Reason,
                ManagerComments = leaves.ManagerComments
            };
            ud_DbContext.Leaves.Add(le);
            await ud_DbContext.SaveChangesAsync();
            return le.LeaveId;
        }

        public async Task<int> DeleteLeaves(int id)
        {
            var ar = ud_DbContext.Leaves.Where(x => x.LeaveId == id).FirstOrDefault();
            if (ar != null)
            {
                ud_DbContext.Leaves.Remove(ar);
            }

            await ud_DbContext.SaveChangesAsync();
            return ar.LeaveId;
        }

        public async Task<List<Leave>> LeaveDet()
        {
            List<Leave> leavelst = new List<Leave>();
            var ar = await ud_DbContext.Leaves.ToListAsync();
            foreach (Leave le in ar)
            {
                leavelst.Add(new Leave
                {
                    LeaveId = le.LeaveId,
                    NoOfDays = le.NoOfDays,
                    StartDate = le.StartDate,
                    EndDate = le.EndDate,
                    LeaveType = le.LeaveType,
                    Status = le.Status,
                    Reason = le.Reason,
                    ManagerComments = le.ManagerComments
                });
            }

            return leavelst;

        }

        public async Task<int> UpdateLeaves(int id, Leave leaves)
        {
            var ar = ud_DbContext.Leaves.Where(x => x.LeaveId == id).FirstOrDefault();
            if (ar != null)
            {

                ar.Status = leaves.Status;
                ar.LeaveType = leaves.LeaveType;
                ar.StartDate = ar.StartDate;
                ar.EndDate = ar.EndDate;

            }

            await ud_DbContext.SaveChangesAsync();
            return ar.LeaveId;
        }
    }

}