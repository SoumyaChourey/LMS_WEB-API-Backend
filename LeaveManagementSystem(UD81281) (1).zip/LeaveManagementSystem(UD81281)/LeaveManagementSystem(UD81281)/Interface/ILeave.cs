﻿using LeaveManagementSystem_UD81281_.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace LeaveManagementSystem_UD81281_.Repository
{
    interface ILeave
    {
        Task<List<Leave>> LeaveDet();
        Task<int> AddLeaves(Leave leaves);
        Task<int> UpdateLeaves(int id, Leave leaves);
        Task<int> DeleteLeaves(int id);
    }
}
