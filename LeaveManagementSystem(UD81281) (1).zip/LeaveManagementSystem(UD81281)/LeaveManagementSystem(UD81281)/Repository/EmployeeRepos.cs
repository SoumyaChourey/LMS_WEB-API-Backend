﻿using AutoMapper;
using LeaveManagementSystem_UD81281_.Models;
using LeaveManagementSystem_UD81281_.Repository;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Leave_Management_System_UD81281_.Repository
{
    public class EmployeeRepo : IEmployee
    {
        private readonly Ud_DbContext ud_DbContext;
        private readonly IMapper mapper;

        public EmployeeRepo(Ud_DbContext ud_DbContext, IMapper mapper)
        {
            this.ud_DbContext = ud_DbContext;
            this.mapper = mapper;
        }

        public async Task<int> AddEmployees(Employee employees)
        {
            var emp = new Employee()
            {
                EmployeeId = employees.EmployeeId,
                EmployeeName = employees.EmployeeName,
                EmployeeEmailId = employees.EmployeeEmailId,
                MobileNo = employees.MobileNo,
                DateJoined = employees.DateJoined,
                Department = employees.Department,
                AvailableLeave = employees.AvailableLeave

            };
            ud_DbContext.Employees.Add(emp);
            await ud_DbContext.SaveChangesAsync();
            return emp.EmployeeId;
        }

        public async Task<int> DeleteEmployees(int id)
        {
            var ar = ud_DbContext.Employees.Where(x => x.EmployeeId == id).FirstOrDefault();
            if (ar != null)
            {
                ud_DbContext.Employees.Remove(ar);
            }

            await ud_DbContext.SaveChangesAsync();
            return ar.EmployeeId;
        }

        public async Task<List<Employee>> GetEmployee()
        {
            List<Employee> emplst = new List<Employee>();
            var ar = await ud_DbContext.Employees.ToListAsync();
            foreach (Employee em in ar)
            {
                emplst.Add(new Employee
                {
                    EmployeeId = em.EmployeeId,
                    EmployeeName = em.EmployeeName,
                    EmployeeEmailId = em.EmployeeEmailId,
                    MobileNo = em.MobileNo,
                    DateJoined = em.DateJoined,
                    Department = em.Department,
                    AvailableLeave = em.AvailableLeave

                });
            }
            return emplst;
        }

        public async Task<int> UpdateEmployees(int id, Employee employees)
        {
            var ar = ud_DbContext.Employees.Where(x => x.EmployeeId == id).FirstOrDefault();
            if (ar != null)
            {
                ar.EmployeeEmailId = employees.EmployeeEmailId;
                ar.MobileNo = employees.MobileNo;
            }

            await ud_DbContext.SaveChangesAsync();
            return ar.EmployeeId;
        }
    }
}
