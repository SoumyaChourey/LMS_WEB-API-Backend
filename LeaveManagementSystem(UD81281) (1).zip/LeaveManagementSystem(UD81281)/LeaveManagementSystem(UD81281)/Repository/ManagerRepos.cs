﻿using LeaveManagementSystem_UD81281_.Models;
using LeaveManagementSystem_UD81281_.Repository;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Leave_Management_System_UD81281_.Repository
{
    public class ManagerRepos : IManager
    {
        private readonly Ud_DbContext ud_DbContext;

        public ManagerRepos(Ud_DbContext ud_DbContext)
        {
            this.ud_DbContext = ud_DbContext;
        }
        public async Task<int> AddManager(Manager managers)
        {
            var man = new Manager()
            {
                ManagerId = managers.ManagerId,
                ManagerName = managers.ManagerName,
                ManagerEmailId = managers.ManagerEmailId,
                MobileNo = managers.MobileNo,

            };
            ud_DbContext.Managers.Add(man);
            await ud_DbContext.SaveChangesAsync();
            return man.ManagerId;
        }

        public async Task<int> DeleteManager(int id)
        {
            var ar = ud_DbContext.Managers.Where(x => x.ManagerId == id).FirstOrDefault();
            if (ar != null)
            {
                ud_DbContext.Managers.Remove(ar);
            }

            await ud_DbContext.SaveChangesAsync();
            return ar.ManagerId;
        }

        public async Task<List<Manager>> GetManager()
        {
            List<Manager> manlst = new List<Manager>();
            var ar = await ud_DbContext.Managers.ToListAsync();
            foreach (Manager m in ar)
            {
                manlst.Add(new Manager
                {
                    ManagerId = m.ManagerId,
                    ManagerName = m.ManagerName,
                    ManagerEmailId = m.ManagerEmailId,
                    MobileNo = m.MobileNo
                });
            }
            return manlst;
        }

        public async Task<int> UpdateManager(int id, Manager managers)
        {
            var ar = ud_DbContext.Managers.Where(x => x.ManagerId == id).FirstOrDefault();
            if (ar != null)
            {
                ar.ManagerEmailId = managers.ManagerEmailId;
                ar.MobileNo = managers.MobileNo;
            }

            await ud_DbContext.SaveChangesAsync();
            return ar.ManagerId;
        }
    }
}
