﻿using System;
using LeaveManagementSystem_UD81281_.Models;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace LeaveManagementSystem_UD81281_.Repository
{
    interface IEmployee
    {
        Task<List<Employee>> GetEmployee();
        Task<int> AddEmployees(Employee employees);
        Task<int> UpdateEmployees(int id, Employee employees);
        Task<int> DeleteEmployees(int id);
    }
}
